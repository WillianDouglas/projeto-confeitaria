Hello,

Thank You for downloading our font "Valentine Soulmate"

NOTE:

By installing or using this font, you are agree to the Product Usage Agreement:

- This font is already FULL VERSION and ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- If you need a custom license please contact us at
elevatypestudio@gmail.com

- Any donation are very appreciated. Paypal account for donation : https://paypal.me/Elevatype
 
Follow our instagram for update : @elevatype

Thank you.

Elevatype Co
Studio