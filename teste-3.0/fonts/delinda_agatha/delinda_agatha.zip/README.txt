NOTE: This font is FREE FOR PERSONAL USE!  

visit our store for commercial use : 
https://www.creativefabrica.com/designer/bluestype-studio/ref/235830/
https://fontbundles.net/bluestype-studio
https://graphicriver.net/user/bluestype-studio/portfolio

Paypal account for donation : https://www.paypal.me/JefriDwiAlfatah

Thank You.